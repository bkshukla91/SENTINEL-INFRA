"""Mobilization-time model on a hub network. Dijkstra + single-edge-failure test.
Speeds are planning assumptions for convoys, not measured values."""
import heapq

SPEED_KMPH = {"road": 40.0, "rail": 35.0}   # average military convoy / rail move, incl. halts
PLANNED_BONUS = {"road": 1.0, "rail": 1.0}


def _graph(edges, include_under_construction=False, removed=None):
    g = {}
    for e in edges:
        if removed and e["edge_id"] == removed:
            continue
        if e["status"] != "operational" and not include_under_construction:
            continue
        hours = float(e["km"]) / SPEED_KMPH[e["mode"]]
        g.setdefault(e["from"], []).append((e["to"], hours, e["edge_id"]))
        g.setdefault(e["to"], []).append((e["from"], hours, e["edge_id"]))
    return g


def shortest(g, src, dst):
    pq = [(0.0, src, [])]
    seen = set()
    while pq:
        t, n, path = heapq.heappop(pq)
        if n == dst:
            return t, path
        if n in seen:
            continue
        seen.add(n)
        for nb, h, eid in g.get(n, []):
            if nb not in seen:
                heapq.heappush(pq, (t + h, nb, path + [eid]))
    return float("inf"), []


def mobilization_matrix(edges, pairs, future=False):
    g = _graph(edges, include_under_construction=future)
    return {f"{a}->{b}": shortest(g, a, b) for a, b in pairs}


def critical_edges(edges, pairs, top=8):
    """Remove each operational edge; measure added hours across all pairs."""
    base = mobilization_matrix(edges, pairs)
    results = []
    for e in edges:
        if e["status"] != "operational":
            continue
        g = _graph(edges, removed=e["edge_id"])
        added, cut = 0.0, 0
        for a, b in pairs:
            t, _ = shortest(g, a, b)
            bt = base[f"{a}->{b}"][0]
            if t == float("inf"):
                cut += 1
            elif bt != float("inf"):
                added += t - bt
        results.append({"edge_id": e["edge_id"], "link": f'{e["from"]}-{e["to"]}',
                        "mode": e["mode"], "added_hours_total": round(added, 1),
                        "pairs_disconnected": cut})
    results.sort(key=lambda r: (-r["pairs_disconnected"], -r["added_hours_total"]))
    return results[:top]


def benefit_of_completion(edges, pairs):
    now = mobilization_matrix(edges, pairs)
    later = mobilization_matrix(edges, pairs, future=True)
    rows = []
    for k in now:
        a, b = now[k][0], later[k][0]
        rows.append({"route": k, "now_h": round(a, 1) if a != float("inf") else None, "after_h": round(b, 1) if b != float("inf") else None,
                     "saved_h": round(a - b, 1) if a != float("inf") else None})
    rows.sort(key=lambda r: -(r["saved_h"] or 0))
    return rows
