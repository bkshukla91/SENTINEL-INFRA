import csv, math, heapq
from pathlib import Path

def haversine(a, b):
    R = 6371.0
    la1, lo1, la2, lo2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    h = math.sin((la2-la1)/2)**2 + math.cos(la1)*math.cos(la2)*math.sin((lo2-lo1)/2)**2
    return 2 * R * math.asin(math.sqrt(h))

def load_nodes(path):
    with open(path, newline="") as f:
        return {r["node"]: {"lat": float(r["lat"]), "lon": float(r["lon"]),
                            "kind": r["kind"], "note": r["note"]} for r in csv.DictReader(f)}

def load_edges(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))
