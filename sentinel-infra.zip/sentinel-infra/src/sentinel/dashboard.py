import html

def build(result, path):
    rows = ""
    for p in result["projects"]:
        tier = p["dual_use"]["tier"]
        flag = "REVIEW" if p["needs_review"] else "ok"
        rows += (f"<tr><td>{html.escape(p['project_key'].title())}</td><td>{p['asset_type']}</td><td>{p['status']}</td>"
                 f"<td>{', '.join(p['states'])}</td><td>{p['cost_crore'] or '-'}</td><td>{p['confidence']}</td>"
                 f"<td><div class='bar'><span style='width:{p['dual_use']['score']}%'></span></div>{p['dual_use']['score']} ({tier})</td>"
                 f"<td>{p['delay_risk']['level']}</td><td class='{flag}'>{flag}</td></tr>")
    ce = "".join(f"<tr><td>{c['link']}</td><td>{c['mode']}</td><td>{c['pairs_disconnected']}</td><td>{c['added_hours_total']}</td></tr>" for c in result["critical_edges"])
    cb = "".join(f"<tr><td>{c['route']}</td><td>{c['now_h']}</td><td>{c['after_h']}</td><td>{c['saved_h']}</td></tr>" for c in result["completion_benefit"])
    leads = "".join(f"<li><b>{html.escape(l['source'])}</b>: {html.escape(l['text'])}</li>" for l in result["unverified_leads"])
    page = f"""<!doctype html><html><head><meta charset='utf-8'><title>SENTINEL-INFRA</title>
<style>body{{font-family:Segoe UI,Arial;margin:24px;background:#f4f5f2;color:#1d2a1f}}h1{{color:#2f4a2a}}
table{{border-collapse:collapse;width:100%;margin-bottom:24px;background:#fff}}th,td{{border:1px solid #cfd6c8;padding:6px 8px;font-size:13px;text-align:left}}
th{{background:#3d5a36;color:#fff}}.bar{{background:#e3e7de;height:8px;width:90px;display:inline-block;margin-right:6px}}
.bar span{{display:block;height:8px;background:#b8860b}}.REVIEW{{color:#b00020;font-weight:bold}}</style></head><body>
<h1>SENTINEL-INFRA Dashboard</h1><p>Illustrative data. {result['n_feeds']} feed items processed.</p>
<h2>Project register</h2><table><tr><th>Project</th><th>Type</th><th>Status</th><th>States</th><th>Cost (Rs cr)</th><th>Confidence</th><th>Dual-use</th><th>Delay risk</th><th>Flag</th></tr>{rows}</table>
<h2>Critical links (single-failure test)</h2><table><tr><th>Link</th><th>Mode</th><th>Routes cut</th><th>Added hours</th></tr>{ce}</table>
<h2>Time saved when ongoing links finish</h2><table><tr><th>Route</th><th>Now (h)</th><th>After (h)</th><th>Saved (h)</th></tr>{cb}</table>
<h2>Unverified leads (not in register)</h2><ul>{leads}</ul></body></html>"""
    open(path, "w").write(page)
