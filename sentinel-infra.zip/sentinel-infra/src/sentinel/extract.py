"""Turn raw feed text into structured project records using rules (no external NLP libs)."""
import re

STATES = ["Maharashtra", "Gujarat", "Goa", "Tamil Nadu", "Andhra Pradesh",
          "Telangana", "Kerala", "Madhya Pradesh"]

ASSET_KEYWORDS = [
    ("airport", ["airport", "airstrip"]),
    ("port", [" port", "seaport", "berth"]),
    ("rail", ["railway", "rail ", "freight corridor", "double line", "double-line"]),
    ("highway", ["expressway", "highway", "nh-", "mahamarg", "ring road", "corridor", "four-lane", "six-lane", "6-lane", "4-lane", "road"]),
]

STATUS_KEYWORDS = [
    ("operational", ["operational", "fully open", "already finished", "largely operational"]),
    ("under_construction", ["under construction", "construction under way", "work ", "progressing", "delayed", "pushed"]),
    ("planned", ["planned", "approved", "land acquisition started", "proposed"]),
]

PROJECT_KEYS = {
    "samruddhi mahamarg": ["samruddhi", "mumbai-nagpur", "mumbai nagpur"],
    "vadhavan": ["vadhavan"],
    "chennai bengaluru": ["chennai-bengaluru", "chennai bengaluru"],
    "western dedicated freight": ["western dedicated freight", "western dfc"],
    "vizhinjam": ["vizhinjam"],
    "hyderabad vijayawada": ["hyderabad-vijayawada", "hyderabad vijayawada", "nh-65"],
    "mopa goa": ["mopa"],
    "visakhapatnam raipur": ["visakhapatnam-raipur"],
    "bhopal jabalpur": ["bhopal-jabalpur"],
    "indore bhopal rail": ["indore-bhopal"],
    "hyderabad rrr": ["regional ring road"],
    "mumbai pune expressway": ["mumbai pune expressway"],
}

COST_RE = re.compile(r"(?:rs\.?|₹)?\s*([\d,]+(?:\.\d+)?)\s*crore", re.I)
KM_RE = re.compile(r"([\d,]+(?:\.\d+)?)\s*km", re.I)
YEAR_RE = re.compile(r"(?:completion|expected|pushed to|by)\s*(?:to\s*)?(20\d\d)|(20\d\d)\s*(?:under)", re.I)
PCT_RE = re.compile(r"(\d{1,3})\s*%\s*complete", re.I)


def _num(s):
    return float(s.replace(",", ""))


def detect_key(text):
    t = text.lower()
    for key, pats in PROJECT_KEYS.items():
        if any(p in t for p in pats):
            return key
    return None


def detect_asset(text):
    t = " " + text.lower() + " "
    for kind, words in ASSET_KEYWORDS:
        if any(w in t for w in words):
            return kind
    return "unknown"


def detect_status(text):
    t = text.lower()
    if "pending" in t and "operational" in t:
        return "operational"
    for st, words in STATUS_KEYWORDS:
        if any(w in t for w in words):
            return st
    return "unknown"


def extract(item):
    text = item["text"]
    cost = COST_RE.search(text)
    km = KM_RE.search(text)
    yr = YEAR_RE.search(text)
    pct = PCT_RE.search(text)
    states = [s for s in STATES if s.lower() in text.lower()]
    return {
        "feed_id": item["id"],
        "source": item["source"],
        "source_type": item["source_type"],
        "date": item["date"],
        "project_key": detect_key(text),
        "asset_type": detect_asset(text),
        "status": detect_status(text),
        "states": states,
        "cost_crore": _num(cost.group(1)) if cost else None,
        "length_km": _num(km.group(1)) if km else None,
        "completion_year": int(yr.group(1) or yr.group(2)) if yr else None,
        "progress_pct": int(pct.group(1)) if pct else None,
        "lanes": (re.search(r"(\d)-lane", text, re.I) or [None, None])[1] if re.search(r"(\d)-lane", text, re.I) else None,
        "raw": text,
    }
