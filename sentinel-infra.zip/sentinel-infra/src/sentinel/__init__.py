"""SENTINEL-INFRA: OSINT infrastructure intelligence pipeline."""
__version__ = "1.0.0"
