"""Dual-use score 0-100 = asset capability + closeness to defence nodes + readiness."""
from .geo import haversine

ASSET_BASE = {"port": 30, "rail": 28, "airport": 26, "highway": 22, "unknown": 10}
STATUS_PTS = {"operational": 20, "under_construction": 12, "planned": 5, "unknown": 0}
DEFENCE_KINDS = {"army_hub", "naval_hub"}

# rough centre of each project, used only to measure proximity (public map knowledge)
CENTROIDS = {
    "samruddhi mahamarg": (20.1, 76.0), "vadhavan": (19.93, 72.65),
    "chennai bengaluru": (13.0, 78.9), "western dedicated freight": (21.0, 72.9),
    "vizhinjam": (8.38, 76.99), "hyderabad vijayawada": (17.0, 79.6),
    "mopa goa": (15.65, 73.85), "visakhapatnam raipur": (19.5, 82.5),
    "bhopal jabalpur": (23.2, 78.7), "indore bhopal rail": (23.0, 76.6),
    "hyderabad rrr": (17.6, 78.4), "mumbai pune expressway": (18.8, 73.4),
}


def score(project, nodes):
    pts, why = ASSET_BASE.get(project["asset_type"], 10), []
    why.append(f'{project["asset_type"]} base {pts}')
    c = CENTROIDS.get(project["project_key"])
    if c:
        d = min(haversine(c, (n["lat"], n["lon"])) for n in nodes.values() if n["kind"] in DEFENCE_KINDS)
        prox = 25 if d < 60 else 18 if d < 150 else 10 if d < 300 else 4
        pts += prox; why.append(f"nearest army/naval hub {d:.0f} km -> {prox}")
    sp = STATUS_PTS.get(project["status"], 0)
    pts += sp; why.append(f'status {project["status"]} -> {sp}')
    lanes = int(project["lanes"]) if project.get("lanes") else 0
    cap = 10 if (lanes >= 6 or project["asset_type"] in ("port", "rail")) else 5 if lanes >= 4 else 0
    pts += cap; why.append(f"capacity -> {cap}")
    length = project.get("length_km") or 0
    lp = 10 if length >= 400 else 5 if length >= 100 else 0
    pts += lp; why.append(f"length -> {lp}")
    pts = min(100, pts)
    tier = "HIGH" if pts >= 75 else "MEDIUM" if pts >= 55 else "LOW"
    return {"score": pts, "tier": tier, "reasons": why}
