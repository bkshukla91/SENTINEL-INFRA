import json, csv
from pathlib import Path
from .extract import extract
from .verify import consolidate
from .dualuse import score
from .risk import delay_risk
from .geo import load_nodes, load_edges
from . import bottleneck as bn

PAIRS = [("Pune", "Visakhapatnam"), ("Pune", "Kochi"), ("Pune", "Mumbai"),
         ("Hyderabad", "Mumbai"), ("Jabalpur", "Chennai"), ("Nagpur", "Vizhinjam"),
         ("Bhopal", "Visakhapatnam"), ("Indore", "Mundra"), ("Pune", "Vadhavan"),
         ("Hyderabad", "Goa")]


def run(data_dir, out_dir):
    data_dir, out_dir = Path(data_dir), Path(out_dir)
    out_dir.mkdir(exist_ok=True, parents=True)
    feeds = json.loads((data_dir / "feeds.json").read_text())
    nodes = load_nodes(data_dir / "nodes.csv")
    edges = load_edges(data_dir / "network.csv")

    records = [extract(f) for f in feeds]
    projects, orphans = consolidate(records)
    for p in projects:
        texts = [r["raw"] for r in records if r["project_key"] == p["project_key"]]
        p["dual_use"] = score(p, nodes)
        p["delay_risk"] = delay_risk(p, texts)

    result = {
        "projects": projects,
        "unverified_leads": [{"feed_id": o["feed_id"], "source": o["source"], "text": o["raw"]} for o in orphans],
        "critical_edges": bn.critical_edges(edges, PAIRS),
        "completion_benefit": bn.benefit_of_completion(edges, PAIRS),
        "baseline": {k: {"hours": (round(v[0], 1) if v[0] != float("inf") else None), "path": v[1]} for k, v in bn.mobilization_matrix(edges, PAIRS).items()},
        "n_feeds": len(feeds),
    }
    (out_dir / "analysis.json").write_text(json.dumps(result, indent=2))
    with open(out_dir / "projects.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["project", "type", "status", "states", "cost_crore", "km", "confidence", "dual_use", "tier", "delay_risk", "needs_review"])
        for p in projects:
            w.writerow([p["project_key"], p["asset_type"], p["status"], "/".join(p["states"]), p["cost_crore"],
                        p["length_km"], p["confidence"], p["dual_use"]["score"], p["dual_use"]["tier"],
                        p["delay_risk"]["level"], p["needs_review"]])
    return result
