"""Group claims per project, score credibility, flag conflicts."""
from collections import defaultdict

WEIGHT = {"official": 0.90, "news": 0.65, "social": 0.20}
CONFLICT_TOL = 0.15  # 15 percent


def _confidence(records):
    """Noisy-OR: independent sources raise confidence, weak ones barely matter."""
    miss = 1.0
    for r in records:
        miss *= 1 - WEIGHT.get(r["source_type"], 0.1)
    return round(1 - miss, 3)


def _best(records, field):
    """Pick value from highest-credibility, most recent record that has it."""
    cands = [r for r in records if r.get(field) not in (None, [], "unknown")]
    if not cands:
        return None
    cands.sort(key=lambda r: (WEIGHT[r["source_type"]], r["date"]), reverse=True)
    return cands[0][field]


def consolidate(records):
    groups = defaultdict(list)
    orphans = []
    for r in records:
        (groups[r["project_key"]] if r["project_key"] else orphans).append(r)
    projects = []
    for key, rs in groups.items():
        costs = [r for r in rs if r["cost_crore"]]
        conflict = None
        if len(costs) > 1:
            vals = [c["cost_crore"] for c in costs]
            lo, hi = min(vals), max(vals)
            if (hi - lo) / hi > CONFLICT_TOL:
                low_cred = [c["source"] for c in costs if c["source_type"] == "social"]
                conflict = {"min": lo, "max": hi, "note": "cost figures disagree",
                            "low_credibility_sources": low_cred}
        states = sorted({s for r in rs for s in r["states"]})
        projects.append({
            "project_key": key,
            "asset_type": _best(rs, "asset_type"),
            "status": _best(rs, "status"),
            "states": states,
            "cost_crore": _best(rs, "cost_crore"),
            "length_km": _best(rs, "length_km"),
            "completion_year": _best(rs, "completion_year"),
            "progress_pct": _best(rs, "progress_pct"),
            "lanes": _best(rs, "lanes"),
            "sources": sorted({r["source"] for r in rs}),
            "n_reports": len(rs),
            "confidence": _confidence(rs),
            "cost_conflict": conflict,
            "needs_review": bool(conflict) or _confidence(rs) < 0.6,
        })
    projects.sort(key=lambda p: -p["confidence"])
    return projects, orphans
