"""Simple delay / timeline-risk flags."""
CURRENT_YEAR = 2026

def delay_risk(p, feeds_text):
    flags = []
    txt = " ".join(feeds_text).lower()
    for w in ("delayed", "pushed", "land acquisition", "pending"):
        if w in txt:
            flags.append(w)
    if p["status"] == "under_construction" and p["completion_year"] and p["completion_year"] <= CURRENT_YEAR:
        flags.append("completion year already reached")
    if p.get("progress_pct") is not None and p["progress_pct"] < 80 and p.get("completion_year") and p["completion_year"] - CURRENT_YEAR <= 1:
        flags.append("progress low for deadline")
    level = "HIGH" if len(flags) >= 2 else "MEDIUM" if flags else "LOW"
    return {"level": level, "flags": sorted(set(flags))}
