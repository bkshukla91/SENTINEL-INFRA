import argparse
from pathlib import Path
from .pipeline import run
from .dashboard import build

def main():
    ap = argparse.ArgumentParser(description="SENTINEL-INFRA")
    root = Path(__file__).resolve().parents[2]
    ap.add_argument("--data", default=root / "data")
    ap.add_argument("--out", default=root / "outputs")
    a = ap.parse_args()
    res = run(a.data, a.out)
    build(res, Path(a.out) / "dashboard.html")
    print(f"Projects: {len(res['projects'])}, leads: {len(res['unverified_leads'])}")
    for p in res["projects"]:
        print(f"{p['project_key']:28} conf={p['confidence']:<6} dual-use={p['dual_use']['score']:<3} {p['dual_use']['tier']:<6} review={p['needs_review']}")
    print("Outputs in", a.out)

if __name__ == "__main__":
    main()
